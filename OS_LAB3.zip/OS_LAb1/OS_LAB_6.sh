echo "Write command: "
read a;
exec $a
