a=2;
b=3;
echo a: $a;
echo b: $b;

sum=`expr $a + $b`;
echo sum: $sum;

mul=`expr $a \* $b`;
echo mul: $mul;

div=`expr $a / $b`;
echo div: $div;

sub=`expr $a - $b`;
echo sub: $sub;
