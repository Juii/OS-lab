#!/bin/bash
echo a: ;
read a;
echo b: ;
read b;

echo "Enter preferred operation: "
read op;

case $op in

+)sum=`expr $a + $b`
echo sum: $sum;;

\*)mul=`expr $a \* $b`;
echo mul: $mul;;

/)div=`expr $a / $b`;
echo div: $div;;

-)sub=`expr $a - $b`;
echo sub: $sub;;

%)mod=`expr $a % $b`;
echo mod: $mod;;

esac
