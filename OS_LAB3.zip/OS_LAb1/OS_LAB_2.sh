#!/bin/bash
case $2 in

+)sum=`expr $1 + $3`
echo sum: $sum;;

\*)mul=`expr $1 \* $3`;
echo mul: $mul;;

/)div=`expr $1 / $3`;
echo div: $div;;

-)sub=`expr $1 - $3`;
echo sub: $sub;;

%)mod=`expr $1 % $3`;
echo mod: $mod;;

esac
