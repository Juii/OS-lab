a= 1
b=1
x=1
echo $a
echo $b
while [ " $x " -ne 10 ]
do	
	c=`expr $a + $b`
	echo $c
	a=$b
	b=$c
	x=`expr $x + 1`
done
	

