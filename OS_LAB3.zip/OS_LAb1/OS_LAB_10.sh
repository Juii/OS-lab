echo "list of Numbers";
x=1;
i=0;
while [ $x -eq 1 ]
do
	echo "Enter Number: "
	read num[$i]
	i=`expr $i + 1`
	echo "Press 1 to continue , 0 to exit"
	read x
done

echo "Number to be found: "
read a

j=0;
k=0;

for((j=0;j<i;j++))
do
	if [ ${num[$j]} == $a ]
	then
	k=$k+1
	echo "$a is at $j th position"
	fi
done



