echo a: $a;
read a;
echo b:$b;
read b;

if [ "$a" -gt "$b" ]
then
echo "a is larger than b";

elif [ "$a" -eq "$b" ]
then
echo "a is equal to b";

else 
echo "a is smaller than b";
fi
