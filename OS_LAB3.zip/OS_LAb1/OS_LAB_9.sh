x=1
while [ "$x" -ne 0 ]
do
	echo "Capital of Gujarat: "
	read capital
	if [ "Gandhinagar" = "$capital" ] 
	then
	x=0
	else
	x=1
	fi
done
