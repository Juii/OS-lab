echo "Enter Text"
read jan

case $jan in

Jan)echo "January";;

Janu)echo "January";;

Janua)echo "January";;

January)echo "January";;

esac
