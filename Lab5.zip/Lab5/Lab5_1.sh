A=$1
echo $A | rev
