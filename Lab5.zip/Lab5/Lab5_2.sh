	y=$1
	x=`expr $y | rev`
	if [ $x == $1 ]
	then
		echo "The entered string is a palindrome"
	else
		echo "The entered string is not a palindrome"
	
	fi	
