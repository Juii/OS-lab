echo "Enter alphabet: "
read alph

echo "Files starting with alphabet $alph are : "
ls $alph*
