echo "Enter File1: "
read file1

b=0
if test -e $file1
then
	echo "file1 exist"
	b=1
else
	echo "file1 doesn't exist"
fi	

if [ $b -eq 1 ]
then
	a=0
	echo "Enter File2: "
	read file2
	if test -e $file2
	then
		a=1
		echo "file2 exist"
	else
		echo "file2 doesn't exist"
	fi

	if [ $a -eq 1 ]
	then
		cat $file1 >> $file2
	else
		cat $file1 > $file2
	fi
else
	echo "file1 entered is invalid. Enter valid filename"
fi
