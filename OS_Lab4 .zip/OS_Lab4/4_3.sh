echo "Enter Number: "
read n1
echo "Sum of numbers till $n1 is: "
echo "($n1 * ($n1 + 1)) / 2" | bc

