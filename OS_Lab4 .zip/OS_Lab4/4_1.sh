x1=1;
while [ "$x1" -eq 1  ] 
do
	echo n1: ;
	read n1;
	if [ "$n1" -lt 50 ]
	then
	{
	a=`expr $n1 \* $n1`
	echo square $n1: $a;
	}

	else
	echo "Number is not valid"
	fi

done
