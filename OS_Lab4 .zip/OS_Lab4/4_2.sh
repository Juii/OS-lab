echo "Enter pattern to be searched: ";
read a;
echo "Enter FileName: ";
read filename;
grep $a $filename;

if [ $? -eq 0 ]
then              
echo Pattern is found ;
else
echo No such Pattern found;
fi


