echo "Enter filename to find new lines: "
read FileName

sed -n '$=' "$FileName"
