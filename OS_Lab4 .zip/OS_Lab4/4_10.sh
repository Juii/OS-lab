echo "Enter filename to find number of words: "
read FileName
wc -w $FileName
