echo "Enter Actual rent of the house: "
read Rent

echo "Enter your basic salary: "
read BasicSalary

x=0.12 
echo "$Rent - $x * $BasicSalary" | bc
