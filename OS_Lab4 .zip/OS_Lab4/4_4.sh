
var=0
echo "Enter a number: "
read n1
i=2
sum=`expr $n1 / 2`
while [ "$i" -le "$sum" ] 
do
	temp=`expr $n1 % $i`
	if [ $temp -eq 0 ]
	then
        var=`expr $var + 1`
	break
	fi
     	i=`expr $i + 1`
done

if [[ "$var" -eq 0 && "$n1" -ne 1 ]]
then
	echo Prime Number
else
	echo Not a prime number
fi
