echo "Enter the name of file to find spaces: "
read FileName
echo "Number of spaces in a file are: "
wc -l  "$FileName"
